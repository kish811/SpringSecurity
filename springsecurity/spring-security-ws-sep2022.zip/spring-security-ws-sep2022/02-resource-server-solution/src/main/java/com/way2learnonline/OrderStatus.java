package com.way2learnonline;

public enum OrderStatus {
 NEW, APPROVED, REJECTED
}
